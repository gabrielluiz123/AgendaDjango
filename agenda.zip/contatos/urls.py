from django.urls import path, include
from . import viewsORM

urlpatterns = [
    path('', viewsORM.index, name="index"),
    path('login/', include('accounts.urls'), name="logina_index"),
    path('busca/', viewsORM.busca, name="busca"),
    path('<int:contato_id>', viewsORM.ver_contato, name="ver_contato"),
]